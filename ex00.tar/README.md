# Welcome to My Fizzbuzz
***

## Task
Fizzbuzz is considered a widespread problem in Computer Science, so often that it is considered the basics coding logic in exercises. In this exercise, I was tasked of Your project will be to create a my_fizzbuzz() function. It will take a parameter, an integer. You will iterate until you've reached "this" number.

## Description
I was able to solve this problem by creating a function and a parameter within that function. Inside of the function there are if, else statements that ensure the requirements of the code are met.

## Installation
You can install the project by downloading in github on the top right of the project section. There should be a download buttom available to 

## Usage
my_fizzbuzz function will print out numbers from 1 to 100,multiple of three should print “Fizz” and similarly print “Buzz” for multiples of 5 and lastly print “FizzBuzz” for multiples of three and five.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
